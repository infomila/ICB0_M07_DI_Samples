﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20171122_SQLite.db
{
    class DeptDB
    {
        public static string getDepts()
        {
            string res = "";


            using(EmpresaContext emp = new EmpresaContext())
            {
                using (var con = emp.Database.GetDbConnection())
                {
                    con.Open();
                    using (var command = con.CreateCommand())
                    {
                        command.CommandText = " select * from dept";
                        DbDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            string nom = reader.GetString(reader.GetOrdinal("DNOM"));
                            res += nom + ", \n";
                        }
                    }
                }
            }

            return res;
        }
    }
}
